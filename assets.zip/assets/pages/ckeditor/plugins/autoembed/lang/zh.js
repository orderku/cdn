/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'zh', {
	embeddingInProgress: '正在嘗試嵌入已貼上的 URL...',
	embeddingFailed: '這個 URL 無法被自動嵌入。'
} );
